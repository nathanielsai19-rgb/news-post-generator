# InkDrop Scene Pack - Martin Shaw Recasts Four Years on a Welsh Mountainside

Story: Martin Shaw Recasts Four Years on a Welsh Mountainside
Outlet: شبكة تواصل الإخبارية
Link: https://news.google.com/rss/articles/CBMiU0FVX3lxTFA1STdnZlVPb2RSVlo4REV6NG9pMmc5aHF2TXFhTXB0LXF4VkhaTTNpak5Ta2ZoVVBNV1Q4ZUw0Q1hBNmVwMk5yMS1iMmtZdlNFTGVn?oc=5
Generated: 2026-10-20T21:13:52Z · writer: template · style: foggy_forest

## Scene script

LOGLINE: Martin Shaw Recasts Four Years on a Welsh Mountainside. One quiet moment that captures why it matters.

SCENE: Martin Shaw Recasts Four Years on a Welsh Mountainside. Trending: martin shaw. The scene opens on a figure mid-thought.

BEAT: The figure turns toward the light as the moment settles - a decision made.

## Characters

### The figure - the person at the center of the story
- Appearance: rounded low-poly figure: capsule body, sphere head, simple dark eyes
- Clothing: matte single-color body with a bright accent hat
- Expression: still, head slightly raised - mid-thought
- Motivation: to understand what the news means before acting

## Environment & shot

- Location: a quiet place implied by the story
- Time: the time of day the story suggests
- Lighting: key light from the sun with gentle fill
- Weather: cloudy
- Atmosphere: foggy forest mood - calm and unhurried
- Camera: crane_up
- Framing: medium shot on the figure, window behind
- Lens: 50mm equivalent

## Midjourney text-to-video prompt

medium shot on the figure, window behind of The figure (rounded low-poly figure: capsule body, sphere head, simple dark eyes, matte single-color body with a bright accent hat, still, head slightly raised - mid-thought). Martin Shaw Recasts Four Years on a Welsh Mountainside. Trending: martin shaw. The scene opens on a figure mid-thought. a quiet place implied by the story, the time of day the story suggests. soft morning fog, diffused light, muted greens, quiet mood, key light from the sun with gentle fill. Camera: crane_up. Moment: The figure turns toward the light as the moment settles - a decision made. --ar 16:9

## Midjourney image-to-video (upload opening_frame.png as the image)

Camera crane_up, The figure turns toward the light as the moment settles - a decision made. Consistent stylized 3D scene and characters, smooth natural motion, no morphing, no text overlays.

## Reference images

- opening_frame.png - the video's first frame (camera view)
- refs/ref_front.png - three-quarter view of the scene
- refs/ref_high.png - high angle overview
- refs/ref_close.png - close-up on the main character

## Blender scene

scene.blend - open in Blender 5.2 to inspect or re-render the scene.
scene_spec.json - the machine-readable build spec.